/* Motion enhancement: all content remains usable when motion is disabled. */
(() => {
  const reduced = matchMedia('(prefers-reduced-motion: reduce)');
  const spring = 'cubic-bezier(.2,.85,.22,1.15)';
  const ease = 'cubic-bezier(.22,1,.36,1)';
  const seen = new Set();
  let signature = '', observer;
  const run = (el, frames, options = {}) => {
    if (!el || reduced.matches || !el.animate) return;
    return el.animate(frames, { duration: 500, easing: ease, ...options });
  };
  function reveal(el, delay = 0) {
    run(el, [{ opacity: 0, transform: 'translateY(22px) scale(.98)' }, { opacity: 1, transform: 'translateY(0) scale(1)' }], { duration: 700, delay });
  }
  function setupObserver() {
    observer?.disconnect();
    if (reduced.matches || !('IntersectionObserver' in window)) return;
    observer = new IntersectionObserver(entries => {
      let stagger = 0;
      for (const entry of entries) {
        if (!entry.isIntersecting) continue;
        const el = entry.target;
        const key = el.querySelector('[data-detail]')?.dataset.detail || el.dataset.motionKey;
        if (!seen.has(key)) { seen.add(key); reveal(el, Math.min(stagger++ * 55, 220)); }
        observer.unobserve(el);
      }
    }, { threshold: .08 });
  }
  function refresh() {
    const next = document.querySelector('#list-title').textContent + document.querySelector('#search').value;
    if (signature !== next) { seen.clear(); signature = next; }
    observer?.disconnect();
    if (reduced.matches) return;
    document.querySelectorAll('.card').forEach(el => observer?.observe(el));
    document.querySelectorAll('.how, footer').forEach((el, i) => { el.dataset.motionKey = 'section-' + i; observer?.observe(el); });
  }
  function page(el) {
    run(el, [{ opacity: .3, transform: 'translateY(14px)' }, { opacity: 1, transform: 'translateY(0)' }], { duration: 450 });
  }
  function close(dialog) {
    if (!dialog?.open || dialog.dataset.closing) return;
    if (reduced.matches || !dialog.animate) { dialog.close(); return; }
    dialog.dataset.closing = 'true';
    const animation = run(dialog, [{ opacity: 1, transform: 'translateY(0) scale(1)' }, { opacity: 0, transform: 'translateY(24px) scale(.98)' }], { duration: 180, easing: 'ease-in' });
    const finish = () => { dialog.close(); delete dialog.dataset.closing; };
    animation.finished.then(finish, finish);
  }
  window.auraMotion = { refresh, page, close };
  setupObserver();refresh();
  document.querySelectorAll('.hero-copy > *').forEach((el, i) => reveal(el, 80 + i * 85));
  reveal(document.querySelector('.quick'), 250);
  document.querySelectorAll('dialog').forEach(dialog => dialog.addEventListener('cancel', e => { e.preventDefault(); close(dialog); }));
  document.addEventListener('click', e => {
    const button = e.target.closest('button');
    if (!button) return;
    const id = button.dataset.favorite || button.dataset.select;
    if (id) requestAnimationFrame(() => {
      const target = document.querySelector(`[data-${button.dataset.favorite ? 'favorite' : 'select'}="${CSS.escape(id)}"]`);
      run(target, [{ transform: 'scale(.86)' }, { transform: 'scale(1.09)', offset: .65 }, { transform: 'scale(1)' }], { duration: 420, easing: spring });
      if (button.dataset.select) {
        run(document.querySelector('.badge'), [{ transform: 'scale(.6)' }, { transform: 'scale(1.2)', offset: .65 }, { transform: 'scale(1)' }], { duration: 400, easing: spring });
        run(document.querySelector('#floating > button'), [{ transform: 'scale(.98)' }, { transform: 'scale(1)' }], { duration: 400, easing: spring });
      }
      target?.focus({ preventScroll: true });
    });
    if (button.dataset.category) button.scrollIntoView({ behavior: reduced.matches ? 'instant' : 'smooth', block: 'nearest', inline: 'nearest' });
  }, true);
  reduced.addEventListener('change', () => {
    if (reduced.matches) document.getAnimations().forEach(a => a.cancel());
    setupObserver();refresh();
  });
})();
